void main(void)
 { 
   char string[66000L];   // 66,000 bytes

   int values[33000L];    // 33,000 * 2 = 66,000 bytes

   float numbers[17000];  // 17,000 * 4 = 68,000 bytes
 }

