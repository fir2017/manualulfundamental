#include <stdio.h>

void main(void)
 {
   printf("Beta Testing: Last compiled %s %s\n", __DATE__, 
     __TIME__);
 }
