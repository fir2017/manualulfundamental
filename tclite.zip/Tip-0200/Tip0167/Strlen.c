#include <stdio.h>
#include <string.h>

void main(void)
 {
   char book_title[] = "Jamsa\'s C/C++ Programmer\'s Bible";

   printf("%s contains %d characters\n", book_title, strlen(book_title));
 }

