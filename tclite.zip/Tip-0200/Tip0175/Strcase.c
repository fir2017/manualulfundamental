#include <stdio.h>
#include <string.h>

void main(void)
 { 
   printf(strlwr("Jamsa\'s C/C++ Programmer\'s Bible!\n"));
   printf(strupr("Jamsa\'s C/C++ Programmer\'s Bible!\n"));
 }
