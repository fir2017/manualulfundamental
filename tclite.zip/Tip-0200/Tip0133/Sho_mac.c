#define LINE 128
#define TITLE "Jamsa\'s C/C++ Programmer\'s Bible"
#define SECTION "Macros"

void main(void)
{
	char book[LINE];
	char library_name[LINE];

	printf("This book's title is %s\n", TITLE);
	printf(SECTION);
}