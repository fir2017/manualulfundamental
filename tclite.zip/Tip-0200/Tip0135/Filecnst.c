#include <stdio.h>

void main(void)
 {
   printf("The file %s is under Beta testing\n", __FILE__);
 }
