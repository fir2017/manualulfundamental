#include <stdio.h>
#include <math.h>

void main(void)
 {
   printf("Natural log of 256.0 is %f\n", log(256.0));
 }

