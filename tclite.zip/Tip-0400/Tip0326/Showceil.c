#include <stdio.h>
#include <math.h>

void main(void)
 {
   printf("The value %f ceil %f\n", 1.9, ceil(1.9)); 
   printf("The value %f ceil %f\n", 2.1, ceil(2.1));
 }

