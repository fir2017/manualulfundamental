#include <stdio.h>
#include <stdlib.h>

void main(void)
 {
   int i;

   printf("Values from random\n");
   for (i = 0; i < 10; i++)
     printf("%f\n", random(100/100);

   printf("Values from random(-5) to random(5)/n");
   for (i = 0; i < 100; i++)
     printf("%d\n", random(10)-5);
 }

