#include <conio.h>

void main(void)
 {
   clrscr();
 }

