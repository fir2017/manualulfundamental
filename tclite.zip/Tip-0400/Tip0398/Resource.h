//
// Resource.h
//

#define IDI_DIRWALK 	100
#define IDC_TREE 		101
#define IDD_DIRWALK	102

