#include <stdio.h>

void main(void)
 {
   printf("Displaying 0.1234 yields %g\n", 0.1234);
   printf("Displaying 0.00001234 yields %g\n", 0.00001234);
 }

