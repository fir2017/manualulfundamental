// Program: COMMENT.C
// Written by: Kris Jamsa and Lars Klander
// Date written: 08-22-97

// Purpose: Illustrates the use of comments in a C program.

#include <stdio.h>

void main(void)
 {
   printf ("Jamsa\'s C/C++ Programmer\'s Bible!");  // Display a message
 }


