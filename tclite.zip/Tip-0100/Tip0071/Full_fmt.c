#include <stdio.h>

void main(void)
 {
   int int_value = 5;
   
   printf("Left justifed with sign %-+3d\n", int_value);
 }

