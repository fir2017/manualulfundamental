#include <stdio.h>

void main(void)
 {
   char title[255] = "Jamsa\'s C/C++ Programmer\'s Bible";

   printf("The name of this book is %s\n", title);
 }

