#include <stdio.h>

void main(void)
 {
   int age = 41;
   int height = 73;
   int weight = 165;

   printf("The user\'s age: %d weight: %d height: %d\n", age, weight, height);
   printf("%d plus %d equals %d\n", 1, 2, 1 + 2);
 }
