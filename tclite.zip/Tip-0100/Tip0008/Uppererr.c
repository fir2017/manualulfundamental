#include <stdio.h>

void Main(void)
 {
   printf ("This program does not compile.");
 }
