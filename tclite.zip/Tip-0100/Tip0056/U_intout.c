#include <stdio.h>

void main(void)
 {
   unsigned int value = 42000;

   printf("Displaying 42000 as unsigned %u\n", value);
   printf("Displaying 42000 as int %d\n", value);
 }


