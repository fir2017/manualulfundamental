#include <stdio.h> 
void main(void){printf("Jamsa\'s C/C++ Programmer\'s Bible!");}

