#include <stdio.h>

void main(void)
 {
   printf ("This is line one.");
   printf ("This is the second line.");
 }

