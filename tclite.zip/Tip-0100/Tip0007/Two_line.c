#include <stdio.h>

void main(void)
 {
   printf ("This is line one.\n");
   printf ("This is the second line.");
 }

