#include <stdio.h>

void main(void)
 {
   long int one_million = 1000000;

   printf ("One million is %ld\n", one_million);
   printf ("One million is %d\n", one_million);
 
 }

