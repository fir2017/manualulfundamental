#include <stdio.h>

void main(void)
 {
   float value = 1.23456;

   printf ("%12.1e\n", value);
   printf ("%12.3e\n", value);
   printf ("%12.5e\n", value);
 }
