#include <stdio.h>

void main(void)
 {
   int value = 5;

   printf ("%1d\n", value);
   printf ("%2d\n", value);
   printf ("%3d\n", value);
   printf ("%4d\n", value);
 }
