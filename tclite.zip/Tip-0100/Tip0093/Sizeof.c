#include <stdio.h>

void main(void)
 {
   printf("Variables of type int use %d bytes\n", sizeof(int));
   printf("Variables of type float use %d bytes\n", sizeof(float));
   printf("Variables of type double use %d bytes\n", sizeof(double));
   printf("Variables of type unsigned use %d bytes\n", sizeof(unsigned));
   printf("Variables of type long use %d bytes\n", sizeof(long));
 }

