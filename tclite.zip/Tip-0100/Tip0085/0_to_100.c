#include <stdio.h>

void main(void)
 {
   int value = 0;

   while (value <= 100)
     {
       printf("%d\n", value);
       value++;
     }
 }

