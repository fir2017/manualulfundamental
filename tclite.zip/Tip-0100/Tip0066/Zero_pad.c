#include <stdio.h>

void main(void)
 {
   int value = 5;

   printf ("%01d\n", value);
   printf ("%02d\n", value);
   printf ("%03d\n", value);
   printf ("%04d\n", value);
 }
