#include <stdio.h>

void main(void)
 {
   printf("The letter is %c\n", 'A');
   printf("The letter is %c\n", 65);
 }

