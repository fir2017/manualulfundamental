#include <stdio.h>

void main(void)
 {
   print("This program does not link");
 }

