#include <stdio.h>

void main(void)
 {
   int value;

   printf("The address of the variable value is %p\n", &value);
 }

