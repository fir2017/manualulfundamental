#include <stdio.h>

void main(void)
 {
   printf ("Jamsa\'s ");
   printf ("C/C++ Programmer\'s ");
   printf ("Bible!");
 }

