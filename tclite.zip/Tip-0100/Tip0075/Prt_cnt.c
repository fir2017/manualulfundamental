#include <stdio.h>

void main(void)
 {
   int first_count;
   int second_count;

   printf("Jamsa%n\'s C/C++ Programmer\'s Bible%n\n", &first_count, &second_count);
   printf("First count %d Second count %d\n", first_count, second_count);
 }

