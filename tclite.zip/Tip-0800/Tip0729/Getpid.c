#include <stdio.h>
#include <process.h>

void main(void)
 {
   printf("Process id: %X\n", getpid());
 }


