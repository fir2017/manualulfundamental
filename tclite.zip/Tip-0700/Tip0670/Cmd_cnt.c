#include <stdio.h>

void main(int argc, char *argv[])
 {
   printf ("The number of command line entries is %d\n", argc); 
 }

