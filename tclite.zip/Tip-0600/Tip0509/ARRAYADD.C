#include <stdio.h>

void main(void)
 {
   int count[10];
   float salaries[5];
   long distances[10];

   printf("Address of the array count is %x\n", count);
   printf("Address of the array salaries is %x\n", salaries);
   printf("Address of the array distances is %x\n", distances);
 }
