#include <stdio.h>

void main(void)
 {
 	int a = 1, b = 2, c = 3;

   printf("The address of a is %x the value of a is %d\n", &a, a);
   printf("The address of b is %x the value of b is %d\n", &b, b);
   printf("The address of c is %x the value of c is %d\n", &c, c);
 }

