#include <stdio.h>

int tip_count = 1500;  // Global variable

void show_title(void)
 {
   printf("Jamsa\'s C/C++ Programmer\'s Bible");
 }

