#include <stdio.h>

int tip_count = 1500;  // Global variable

static char title[] = "Jamsa\'s C/C++ Programmer\'s Bible";

void show_title(void)
 {
   printf(title);
 }

